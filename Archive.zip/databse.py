import sqlite3
class DatabaseRubika(object):
    def __init__(self , database_name:str ) -> None:
        self.database = sqlite3.connect(
                                database = database_name
                            )
        self.cur = self.database.cursor()
    def search_guid(self , guid_user:str):
        self.guid_user = guid_user
        query = self.cur.execute(
                        "SELECT guid FROM phone_database WHERE guid = ? " ,
                        (self.guid_user,)
                    )
        self.result = query.fetchall()[0][0]
        if self.result:
            new_query = self.cur.execute(
                                "SELECT * phone_database WHERE guid = ?" ,
                                (self.guid_user ,)
                            )
            return new_query.fetchall()[0]
    
        return False
    
    def search_username(self , username:str):
        self.username = username
        query = self.cur.execute(
                        "SELECT username FROM phone_database WHERE username = ? " ,
                        (self.username,)
                    )
        self.result = query.fetchall()[0][0]
        if self.result:
            new_query = self.cur.execute(
                                "SELECT * phone_database WHERE username = ?" ,
                                (self.username ,)
                            )
            return new_query.fetchall()[0]
        
        return False
        
class DatabaseBot:
    def __init__(self , database_name) -> None:
        self.database = sqlite3.connect(
                                database = database_name
                            )
        self.cur = self.database.cursor()
        
    def check_user(self , userid:str):
        query = self.cur.execute("SELECT userid FROM bot_databse WHERE userid = ?" , (userid,))
        if query.fetchall():
            return True
        
        return False
    
    def write_user(self , first_name , last_name , userid , username , time , date_per):
        self.cur.execute(
            '''INSERT INTO bot_database(first_name , last_name , userid , username , time , date_per) VALUES(? ,? , ? , ? , ? , ?)''',
                (first_name , last_name , userid ,username , time , date_per))
        self.database.commit()
    
    def check_per(self , today_date , userid):
        query = self.cur.execute('SELECT date_pre , userid FROM bot_database WHERE userid = ?' , (userid , ))
        result_query = query.fetchall()
        
        if result_query[0][0] < today_date:
            return False
        
        return True 
    def delete_user(self , userid):
        try:
            self.cur.execute(' DELETE FROM bot_database WHERE userid = ?;' , (userid,))
            return True
        except:
            return False