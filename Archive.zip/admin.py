from pyrogram.client import Client
from databse import  DatabaseBot
import config
from datetime import datetime
bot = Client(
        name='admin',
        api_hash='9532637c4d95fbc047a14268cb493bbf',
        api_id='3191570',
        bot_token='5208662211:AAHcUZH5DOVSdlk9mtCjki5TzUOUTw9kekY',
)
database = DatabaseBot(
        database_name=config.database_bot
)

@bot.on_message()
async def main(client , message):
    text = message.text
    if text == '/start':
        await bot.send_message(chat_id=message.chat.id , text='Welcome To Panel Bot')
        await bot.send_message(chat_id=message.chat.id , 
                text='''
                Commands Bot ..!
                \n+-----------------+
                \n/start --> Start Robot
                \n/create_user [userid] [date_per] --> create a new user for robot 
                \n/delete_user [userid] --> delete a user from bot
                \n/get_members [userid] --> get a number of members
                \n/get_user [userid] --> get informations user from bot
                ''')

    elif text.split(' ')[0] == '/create_user':
        date = datetime.today()
        informations = await bot.get_users(text.split(' ')[1])
        result = str(date.year) +'/'+str(date.month) +'/' + str(date.day)
        try:
           database.write_user(
                first_name=informations.user.first_name,
                last_name=informations.user.last_name,
                userid=text.split(' ')[1],
                username=informations.user.username,
                time=result,
                date_per=text.split(' ')[2],)
        
        except:
           database.write_user(
                first_name='',
                last_name='',
                userid=text.split(' ')[1],
                username='',
                time=result,
                date_per=text.split(' ')[2],)

    elif text.split(' ')[0] == '/delete_user':
        result = database.delete_user(userid=text.split(' ')[1])
        if result == True:
            await bot.send_message(chat_id=message.chat.id , text=f'removed user {text.split(" ")[1]}')
        else:
            await bot.send_message(chat_id=message.chat.id , text='E:Cant Remove User')