from pyrogram.client import Client
from databse import DatabaseRubika , DatabaseBot
import config
bot = Client(
    name="app" ,
    api_hash='9532637c4d95fbc047a14268cb493bbf' , 
    api_id='3191570' ,
    bot_token='5208662211:AAHcUZH5DOVSdlk9mtCjki5TzUOUTw9kekY')

database = DatabaseRubika(
            database_name=config.database)

bot_database = DatabaseBot(
            database_name=config.database_bot)

@bot.on_message()
async def main(client , message):
    if bot_database.check_user(
            userid=message.from_user.id) == True and bot_database.check_per(
                userid=message.from_user.id) == True:
        
        if message.text == '/start':
            await bot.send_message(
                        chat_id=message.chat.id,
                        text="ฬєlς๏๓є t๏ ๓א ๒๏t\ภ๓א ςђคภภєl tєlєﻮгค๓: @єlŦ_รєςยгเtא_ςא๒єг"
                    )
            await bot.send_message(
                        chat_id=message.chat.id,
                        text='''
                        \n Bot Commands !
                        \n+-------------------+
                        \n1) /start --> start robot
                        \n2) /search_guid --> search guid user from database rubika
                        \n3) /search_username --> search username from database rubika
                        \n4) /profile --> my profile in bot    
                        '''
            )
        elif message.text.split(' ')[0] == '/search_guid':
            await bot.send_message(

                chat_id=message.chat.id,

                text="קlєครє ฬเtє..!"
            )

            result = database.search_guid(
                        guid_user=message.text.split(' ')[1]
                    )

            if result != False:

                await bot.send_message(chat_id = message.chat.id , text=result)

            else:

                await bot.send_message(chat_id=message.chat.id , text='ภ๏t Ŧ๏ยภ๔ ยรєг..!')
        elif message.text.split(' ')[0] == "/search_username":
            await bot.send_message(

                chat_id=message.chat.id,

                text="Please Wite..!"
            )

            result = database.search_username(
                        username=message.text.split(' ')[1]
                    )

            if result != False:
                await bot.send_message(
                            chat_id = message.chat.id ,
                            text = result)
            else:
                await bot.send_message(
                            chat_id = message.chat.id , 
                            text = 'ภ๏t Ŧ๏ยภ๔ ยรєг..!')

    elif bot_database.check_user(
            userid=message.from_user.id) == True and bot_database.check_per(
                userid=message.from_user.id) == False:
            await bot.send_message(
                        chat_id = message.chat.id ,
                        text = '๒ยא ๒๏t..!')

    else:
        await bot.send_message(
                    chat_id = message.chat.id ,
                    text = 'א๏ย ςคภ t ยรє tђє ๒๏t קlєครє ๒ยא ๒๏t..!')

if __name__ == "__main__":
    bot.run()

